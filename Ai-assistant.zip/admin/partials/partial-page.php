<div class="ai-pages-search">
    <input type="text" id="ai_pages_search" placeholder="Search pages..." autocomplete="off">
</div>

<div id="ai-pages-results" class="ai-pages-results">
    <p class="ai-pages-initial">Start typing to search, or wait while we load pages…</p>
</div>