<div class="postbox closed">
    <div class="postbox-header">
        <h2>Miscelleneous Task</h2>
    </div>
    <div class="inside">
        <ul class="action__list task-list">
            <?php include plugin_dir_path(__FILE__) . '../partials/partial-miscelleneous_task.php'; ?>
        </ul>
    </div>
</div>