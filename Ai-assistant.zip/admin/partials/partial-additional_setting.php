<li><span class="open__child">Change link to admin page</span>
    <div class="action__setting">
        <input type="text" name="admin__page_link" placeholder="Admin Page Link">
        <?php ai_assistant_render_spark_button('change__admin_page_link'); ?>
    </div>
</li>