<div style="width: 30%;">
    <!-- Theme Files Box -->
    <?php include plugin_dir_path(__FILE__) . '../partials/accordion-themefiles.php'; ?>
    <!-- Tasks Box -->
    <?php include plugin_dir_path(__FILE__) . '../partials/accordion-tasks.php'; ?>
    <!-- Custom Field Box -->
    <?php include plugin_dir_path(__FILE__) . '../partials/accordion-acf.php'; ?>
    <!-- Contact Box -->
    <?php include plugin_dir_path(__FILE__) . '../partials/accordion-contact.php'; ?>
    <!-- Contact Box -->
    <?php include plugin_dir_path(__FILE__) . '../partials/accordion-miscelleneous_task.php'; ?>
    <!-- Coder Box -->
    <?php include plugin_dir_path(__FILE__) . '../partials/accordion-coder.php'; ?>
    <!-- Customizer-->
    <?php include plugin_dir_path(__FILE__) . '../partials/accordion-customizer.php'; ?>
</div>






