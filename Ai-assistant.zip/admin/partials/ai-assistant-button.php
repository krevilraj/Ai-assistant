<button  class="change_setting" data-action="<?php echo esc_attr($action_value); ?>">
    <div class="icon-wrapper">
                <span class="icon">
                    <span class="dashicons dashicons-thumbs-up flip-vertical"></span>
                </span>
        <div class="border"><span></span></div>
        <div class="satellite">
            <span></span><span></span><span></span>
            <span></span><span></span><span></span>
        </div>
    </div>
</button>